from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals
from flask_mail import Mail, Message
from flask import Flask

from rasa_sdk import Action
from rasa_sdk.events import SlotSet
import zomatopy
import json

class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_search_restaurants'
	def run(self, dispatcher, tracker, domain):
		config={ "user_key":"277a9180bb7dcaebff8d52dbefe41b57"}
		zomato = zomatopy.initialize_app(config)
		tier1and2Cities=['Bangalore', 'Chennai', 'Delhi', 'Hyderabad', 'Kolkata', 'Mumbai', 'Ahmedabad', 'Pune','Agra', 'Ajmer', 'Aligarh', 'Amravati','Amritsar', 'Asansol', 'Aurangabad', 'Bareilly', 'Belgaum', 'Bhavnagar', 'Bhiwandi', 'Bhopal','Bhubaneswar', 'Bikaner', 'Bilaspur', 'Bokaro Steel City', 'Chandigarh', 'Coimbatore', 'Nagpur','Cuttack', 'Dehradun', 'Dhanbad', 'Bhilai', 'Durgapur', 'Erode', 'Faridabad', 'Firozabad', 'Ghaziabad','Gorakhpur', 'Gulbarga', 'Guntur', 'Gwalior', 'Gurgaon', 'Guwahati', 'Hamirpur', 'Hubli','Dharwad','Indore', 'Jabalpur', 'Jaipur', 'Jalandhar', 'Jammu', 'Jamnagar', 'Jamshedpur', 'Jhansi', 'Jodhpur','Kakinada', 'Kannur', 'Kanpur', 'Kochi', 'Kolhapur', 'Kollam', 'Kozhikode', 'Kurnool', 'Ludhiana','Lucknow', 'Madurai', 'Malappuram', 'Mathura', 'Goa', 'Mangalore', 'Meerut', 'Moradabad','Mysore', 'Nanded', 'Nashik', 'Nellore', 'Noida', 'Patna', 'Pondicherry', 'Purulia', 'Prayagraj',        'Raipur', 'Rajkot', 'Rajahmundry', 'Ranchi', 'Rourkela', 'Salem', 'Sangli', 'Shimla', 'Siliguri', 'Solapur',        'Srinagar', 'Thiruvananthapuram', 'Thrissur', 'Tiruchirappalli', 'Tiruppur', 'Ujjain', 'Bijapur', 'Vadodara','Varanasi', 'Vasai-Virar City', 'Vijayawada', 'Vellore', 'Warangal', 'Surat','Visakhapatnam','bengaluru','dilli' ,'new delhi','calcutta','Bombay','Puna','Amratsar','Barelly','Bhuvaneshwar','Bokaro','Gurugram','Merath','Muradabad']
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		location_detail=zomato.get_location(loc, 1)
		d1 = json.loads(location_detail)
		lat=d1["location_suggestions"][0]["latitude"]
		lon=d1["location_suggestions"][0]["longitude"]
		cuisines_dict={'Mexican':73,'chinese':25,'American':1,'italian':55,'north indian':50,'south indian':85}
		results=zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)), 5)
		d = json.loads(results)
		response=""
		notTier1and2=0
		if d['results_found'] == 0:
			response="no results found"
			notTier1and2=-1
		if(loc in tier1and2Cities):
			for restaurant in d['restaurants']:
				response=response+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+ "has been rated"+restaurant['restaurant']['user_rating']['aggregate_rating']+"\n"
				notTier1and2=1
		if(notTier1and2==0):
			response="We do not provide services in your city currently"        
		dispatcher.utter_message("-----"+response)
		return [SlotSet('location',loc)]



class ActionSendMail(Action):


	def name(self):
		return 'action_send_mail'
	def run(self, dispatcher, tracker, domain):
		app = Flask(__name__)
		with app.app_context():
			app.config.update(
			DEBUG=True,
			#EMAIL SETTINGS
			MAIL_SERVER='smtp.gmail.com',
			MAIL_PORT=465,
			MAIL_USE_SSL=True,
			MAIL_USERNAME = 'iamnotabot25101990@gmail.com',
			MAIL_PASSWORD = 'k@hindoorjabdindhaljaye'
			)
			mail = Mail(app)
			response=""
			try:
				msg = Message("Restaurant Details",
			sender="iamnotabot25101990@gmail.com",
			recipients=["techyogi25@email.com"])
				msg.body = "Yo!\nHave you heard the good word of Python???"           
				mail.send(msg)
				response='Mail Sent !'
				dispatcher.utter_message("-----"+response)
				return response
			except Exception as e:
				response=str(e)
				return(response)